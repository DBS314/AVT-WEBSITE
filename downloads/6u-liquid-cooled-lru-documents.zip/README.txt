Product: 6U Liquid-cooled LRU
Integrated line replaceable unit

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.

Configuration notes:
The populated configuration contains 13 cards. Total backplane slot capacity is under review.
