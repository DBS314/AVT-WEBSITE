Product: 6U OpenVPX Agilex FPGA
Radar signal & data processing

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.
