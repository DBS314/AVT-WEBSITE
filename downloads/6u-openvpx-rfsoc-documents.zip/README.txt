Product: 6U OpenVPX RFSoC
Multi-channel transmit & receive

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.
