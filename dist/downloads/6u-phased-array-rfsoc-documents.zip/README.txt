Product: 6U Phased-array RFSoC
Antenna backplane processing

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.
