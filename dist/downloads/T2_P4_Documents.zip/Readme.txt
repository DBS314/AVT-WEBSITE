T2_P4 | 6U OpenVPX AMD Versal ACAP
Revision 03 | 17 November 2026
Specifications are configurable design targets. Released configuration and qualification status require confirmation.
Reference diagrams can differ from the released implementation.
