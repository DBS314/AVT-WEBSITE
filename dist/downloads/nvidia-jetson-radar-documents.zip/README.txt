Product: NVIDIA Jetson Radar Processor
Tracking, perception & AI inference

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.
