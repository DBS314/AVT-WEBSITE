Product: 3U OpenVPX Agilex FPGA
Radar signal & data processing

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.

Configuration notes:
RF channel count, converter sample rate and memory capacity are under review. Contact engineering for confirmed specifications.
