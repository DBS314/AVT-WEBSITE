Product: 3U OpenVPX Versal
Radar signal & data processing

Datasheet: original supplied product brochure.
Block diagram: exact source image, also provided as a standalone PDF.
