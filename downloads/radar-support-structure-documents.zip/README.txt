Product: Radar Support Structure
Phased-array installation framework

Datasheet: original supplied product brochure.
A block diagram was not included in the supplied source material. Contact info@avarthana.com for this document.
